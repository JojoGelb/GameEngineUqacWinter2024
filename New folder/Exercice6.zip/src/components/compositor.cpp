#include <simplege/pch/precomp.h>

#include <simplege/simplege.h>

#include "compositor.h"

using json = nlohmann::json;

namespace SimpleGE
{
} // namespace SimpleGE
