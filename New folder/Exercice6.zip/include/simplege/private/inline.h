#pragma once

#include <simplege/private/compositor.inl>
#include <simplege/private/material.inl>