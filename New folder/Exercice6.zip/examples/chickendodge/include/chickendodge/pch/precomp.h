#define _CRT_SECURE_NO_WARNINGS

#include <simplege/pch/precomp.h>

#include <simplege/simplege.h>