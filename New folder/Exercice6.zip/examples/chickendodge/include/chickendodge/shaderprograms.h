#pragma once

#include "chickendodge/pch/precomp.h"

namespace ChickenDodge
{
  static inline void RegisterGameShaderPrograms() { using ShaderProgram = SimpleGE::Graphic::BaseShaderProgram; }
} // namespace ChickenDodge