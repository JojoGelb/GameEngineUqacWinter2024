#pragma once

#include <gfxapi/private/commandbuffer.inl>
#include <gfxapi/private/memorymap.inl>